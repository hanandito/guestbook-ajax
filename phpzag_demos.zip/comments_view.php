<?php 
include('header.php');
?>
<title>Testimonial Harita Gallery - Harita</title>
<script src="js/comments.js"></script>
<?php include('container.php');?>
	<div class="container">		
		<h2>View Testimonial</h2>		
		<br>	
		<br>
        <div id="showComments"></div>
		   
</div>	
<?php include('footer.php');?>